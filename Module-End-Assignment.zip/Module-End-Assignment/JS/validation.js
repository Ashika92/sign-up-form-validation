document.addEventListener('DOMContentLoaded', function () {
  const form = document.querySelector('.needs-validation');
  const password = document.getElementById('password');
  const confirmPassword = document.getElementById('confirmPassword');

  // Real-time password match validation
  confirmPassword.addEventListener('input', function () {
    if (password.value !== confirmPassword.value) {
      confirmPassword.setCustomValidity('Passwords do not match');
    } else {
      confirmPassword.setCustomValidity('');
    }
  });

  form.addEventListener('submit', function (event) {
    // Check password match before submitting
    if (password.value !== confirmPassword.value) {
      confirmPassword.setCustomValidity('Passwords do not match');
    } else {
      confirmPassword.setCustomValidity('');
    }

    if (!form.checkValidity()) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      // Redirect to success.html
      event.preventDefault();
      window.location.href = "signup.html";
    }

    form.classList.add('was-validated');
  }, false);
});
